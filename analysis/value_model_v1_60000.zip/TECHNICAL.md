# Value Model V1 60000 Snapshot

## 目的

這份資料包保留第一版 value-minimax 模型的 60,000 筆訓練結果，方便之後分析、比較、或回頭重現問題。

這版模型的核心用途是：用盤面 value model 評分局面，再讓 value-minimax 用模型排序候選手，減少搜尋量。

## 內容

| 檔案 | 說明 |
| --- | --- |
| `value_data_60000.csv` | 60,000 筆訓練資料，格式為 `target,f0..f191` |
| `train_60000_e10.csv` | 10 epoch 訓練紀錄 |
| `value_ai_eval.csv` | value-minimax vs old minimax 的 40 場對戰結果 |
| `value_weights.bin` | 訓練完成後的模型權重 |
| `SHA256SUMS.txt` | 本包檔案雜湊，方便確認資料未被改動 |

## 模型設定

- 特徵數：192
- 模型：線性權重加總後通過 `tanh`
- 輸出範圍：`[-1, 1]`
- 分數視角：黑方分數為正，白方分數為負
- 搜尋版本：value-minimax
- 目前預設搜尋：depth 2、top-K 8

## 訓練資料來源

資料由自我對局產生，每個盤面用舊 evaluator / old minimax 產生 target。

走子策略混合：

- 40% random
- 30% greedy
- 20% old minimax depth 1
- 10% old minimax depth 2

target teacher 混合：

- 70% old minimax depth 2
- 20% old minimax depth 1
- 10% static evaluator

注意：這代表模型主要是在模仿舊 minimax，不是直接從真實勝負結果學習。

## 訓練參數

- rows：60,000
- train rows：54,000
- validation rows：6,000
- epochs：10
- learning rate：0.01
- L2：0.00001
- model output：`models/value_weights.bin`

## 訓練結果

| Epoch | Train MSE | Val MSE |
| --- | ---: | ---: |
| 1 | 0.29911482 | 0.28576735 |
| 2 | 0.29258081 | 0.27693099 |
| 3 | 0.28759840 | 0.27409613 |
| 4 | 0.28665748 | 0.27024037 |
| 5 | 0.28745079 | 0.27122071 |
| 6 | 0.29299021 | 0.28061360 |
| 7 | 0.29122856 | 0.27913573 |
| 8 | 0.28849089 | 0.27848375 |
| 9 | 0.30394557 | 0.29280630 |
| 10 | 0.28763023 | 0.27307996 |

最佳 validation MSE 出現在 epoch 4：`0.27024037`。

## 對戰評估摘要

40 場 value-minimax vs old minimax depth 2：

- Value wins：3
- Old minimax wins：26
- Draws / max-ply ongoing：11
- Value total thinking time：52.916 秒
- Old minimax total thinking time：128.766 秒
- 平均手數：193.225 ply
- 總時間約快：2.43x

結論：這版速度有變快，但棋力明顯弱於 old minimax。

## 已知問題

1. `ply_count` 被放進特徵，可能造成干擾。
   - 同一個殘局如果出現在第 100 手或第 1000 手，模型會看成不同局面。
   - 下一版建議移除，改用盤面本身的 phase 特徵。

2. teacher 太弱。
   - 大多數 target 來自 old minimax depth 2。
   - 模型上限會被舊 minimax 限制，很難穩定超越它。

3. top-K 剪枝太激進。
   - 目前 top-K 8 很快，但如果模型排序錯，真正好棋可能直接被剪掉。
   - 下一版建議加入有限額的 tactical move 保底。

4. 評估方式還不夠穩。
   - 目前對戰從固定初始局面開始。
   - 下一版建議加入 random opening、多 seed、固定測試局面集。

## 建議下一版方向

1. 先移除 `ply_count`，更新模型 schema，重新產資料。
2. 改善 eval，讓測試結果更可信。
3. 搜尋改成「戰術保底 + 模型排序 top-K」。
4. 部分訓練資料改用更深 teacher，例如 depth 3，只用在抽樣盤面避免產生時間爆炸。
5. 保留每次訓練的 dataset、log、model、eval CSV、技術 Markdown，方便橫向比較。

