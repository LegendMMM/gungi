# Value Model V2 Run

## Purpose

This package keeps one Value-Minimax V2 run together for analysis.

## Contents

- `dataset.csv`: V2 value training dataset.
- `model.bin`: trained V2 model weights.
- `train_log.csv`: epoch-level train/validation MSE.
- `eval_games.csv`: per-game evaluation log, if available.
- `eval_summary.csv`: aggregate evaluation metrics, if available.
- `manifest.json`: source paths and run metadata.
- `SHA256SUMS.txt`: file hashes for integrity checks.

## V2 Notes

- Model schema: V2.
- Default model path: `models/value_weights_v2.bin`.
- `ply_count` is not used as a value feature.
- Search uses a fixed top-K cap with a bounded tactical safety bucket.
- Evaluation supports random openings and multiple seeds.

## Recommended Commands

```powershell
tools\gen_value_data.exe 100000 value_data_v2_100k.csv 1
tools\train_value.exe value_data_v2_100k.csv models\value_weights_v2.bin 15 0.01 0.00001 train_value_v2.csv
tools\eval_value_ai.exe --games 100 --model models\value_weights_v2.bin --seed 1 --seed-count 4 --depth 2 --top-k 12 --max-ply 400 --opening-min 6 --opening-max 12 --output value_ai_eval_v2.csv --summary value_ai_eval_v2_summary.csv
powershell -ExecutionPolicy Bypass -File tools\package_value_run.ps1 -Name value_model_v2_100k_e15
```

## Additional Top-K 8 Eval

The package also includes `eval_top8_games.csv` and `eval_top8_summary.csv` from the same model and opening settings, only changing top-K from 12 to 8.

## Additional Max-Ply 3000 Eval

The package also includes `eval_long_3000_games.csv` and `eval_long_3000_summary.csv` from the same V2 20k model using depth 2, top-K 12, random openings, 20 games, and `--max-ply 3000`.

This diagnostic was added because the original max-ply 400 eval produced many timeouts.

## Official Max-Ply 3000 Eval, 100 Games

The package also includes `eval_100g_3000_games.csv` and `eval_100g_3000_summary.csv` from the same V2 20k model using depth 2, top-K 12, random openings, 100 games, and `--max-ply 3000`.

This is the current official evaluation setting. It replaces max-ply 400 for serious comparisons.
